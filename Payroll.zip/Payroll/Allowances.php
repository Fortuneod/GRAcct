<?php
	ini_set('display_errors',0);
	
	include("connect.php");
	
	$all=mysql_query("SELECT * FROM allowances");
	$rall=mysql_fetch_array($all);
	
	$med=$rall['medical'];
	$trp=$rall['transport'];
	$meal=$rall['meal'];
	$hzd=$rall['hazard'];
	
?>