<?php
	
	session_start();
	$month=$_SESSION['month'];
	$year=$_SESSION['year'];
	
	echo $month;
	echo "<br>";
	echo $year; 
	
	?>