<style type="text/css">
	* {margin: 0;}
	page {background:#fff;}
	#letter{width:200mm;padding-left:5mm;max-width:200mm;}
	
</style>