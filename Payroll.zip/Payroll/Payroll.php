<?php
	ini_set('display_errors',0);
	
	session_start();
	if(isset($_SESSION['admin']) || isset($_SESSION['username'])){
		
	if($_SESSION['admin']==true){
		$username=$_SESSION['admin'];
	}
		
	if($_SESSION['username']==true){
		$username=$_SESSION['username'];
	}
	
	$month=$_SESSION['month'];
	$year=$_SESSION['year'];
	
	include("Details.php");
	include("Deductions.php");
	include("Allowances.php");
	
	$tgrs=0;
	
	$stf=mysql_query("SELECT * FROM `staff_info`");
	while($rstf=mysql_fetch_array($stf)){
		$stfid=$rstf['staffid'];
		$stfname=$rstf['name'];
		$sex=$rstf['sex'];
		$dept=$rstf['dept'];
		$design=$rstf['design'];
		$grdlvl=$rstf['gradelvl'];
		$basicslry=$rstf['basicslry'];
?>
<style type="text/css">
	* {margin: 0;}
	page {background:#fff;}
	#letter{width:200mm;padding-left:5mm;max-width:200mm;}
	</style>
<page>
	<div id="letter"><br>
	<table border="0" align="center"><tr><td align="center" style="font-size:40px;font-weight:bold;border:hidden;color:#008;"><img src="../Images/<?php echo $logo; ?>" width="100" height="100" style="float:left;margin-top:-20px;margin-left:-35px;"> &nbsp;<?php echo $cmpname; ?></td></tr></table><br>
	<?php
	$taxdd=$tax/100 * $basicslry;
	$pendd=$pen/100 * $basicslry;
	$levydd=$levy/100 * $basicslry;
	
	$medal=$med/100 * $basicslry;
	$trpal=$trp/100 * $basicslry;
	$mealal=$meal/100 * $basicslry;
	$hzdal=$hzd/100 * $basicslry;
	
	$totdd=$taxdd + $pendd + $levydd;
	$total=$medal + $trpal + $mealal + $hzdal;
	$grpay=$basicslry + $total;
	$netpay=$grpay - $totdd;
	?>
	<h1 align="center">PAYSLIP FOR <?php echo $month.', '.$year; ?></h1><br>
	
	<table border="0" align="center" cellpadding=10 cellspacing=5>
	<tr>
	<td colspan=3><hr></td>
	</tr>
	<tr width="700">
	<td width="250">Staff ID: <?php echo $stfid; ?> </td>
	<td width="250"> Name: <?php echo $stfname; ?> </td>
	<td width="200">Sex: <?php echo $sex; ?></td>
	</tr>
	<tr>
	<td>Dept: <?php echo $dept; ?></td>
	<td>Designation: <?php echo $design; ?></td>
	<td>Grade Level: <?php echo $grdlvl; ?> </td>
	</tr>
	<tr>
	<td>Basic Salary: N <?php echo number_format($basicslry, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td colspan=3><hr></td>
	</tr>
	</table>
	<table border="0" cellspacing=10 cellpadding=10 style="width:80%;">
	<tr>
	<td colspan=3 style="font-weight:bold;" width="600">Allowances</td>
	</tr>
	<tr>
	<td width="200">Medical Allowance</td>
	<td colspan=2 align="right"><?php echo number_format($medal, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td>Transport Allowance</td>
	<td colspan=2 align="right" ><?php echo number_format($trpal, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td>Meal Allowance</td>
	<td colspan=2 align="right"><?php echo number_format($mealal, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td>Hazard Allowance</td>
	<td colspan=2 align="right"><?php echo number_format($hzdal, 2, ".", ","); ?></td>
	</tr>
	<tr style="text-decoration:underline;font-weight:bold;">
	<td>Total Allowances</td>
	<td colspan=2 align="left"><?php echo number_format($total, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td colspan=3 style="font-weight:bold;">&nbsp;</td>
	</tr>
	<tr>
	<td colspan=3 style="font-weight:bold;">Deductions</td>
	</tr>
	<tr>
	<td>Tax</td>
	<td colspan=2 align="right"><?php echo number_format($taxdd, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td>Pension</td>
	<td colspan=2 align="right"><?php echo number_format($pendd, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td>Levy</td>
	<td colspan=2 align="right"><?php echo number_format($levydd, 2, ".", ","); ?></td>
	</tr>
	<tr style="text-decoration:underline;font-weight:bold;">
	<td>Total Deductions</td>
	<td colspan=2 align="left"><?php echo number_format($totdd, 2, ".", ","); ?></td>
	</tr>
	<tr>
	<td colspan=3 style="font-weight:bold;">&nbsp;</td>
	</tr>
	<tr>
	<td><h3>Net Pay:</h3></td>
	<td colspan=2 align="right"><h3>N <?php echo number_format($netpay, 2, ".", ","); ?></h3></td>
	<hr style="margin-left:10px;">
	</tr>
	</table>
	</div>
</page>

<?php
	$tgrs += $grpay;
}
	mysql_query("CREATE TABLE IF NOT EXISTS `salaries` (
		`id` int(11) unsigned not null auto_increment,
		`month` varchar(20) not null,
		`year` varchar(10) not null,
		`amount` varchar(50) not null,
		
		PRIMARY KEY (id)
		)ENGINE=InnoDB CHARSET=DEFAULT AUTO_INCREMENT=1");
		
		$check=mysql_query("SELECT * FROM `salaries` WHERE month='$month' && year='$year'");
		$count=mysql_num_rows($check);
		if($count<=0){
			$sql="INSERT INTO `salaries` VALUES('', '$month', '$year', '$tgrs')";
			}
			else{
				$sql="UPDATE `salaries`set amount='$tgrs' WHERE WHERE month='$month' && year='$year'";
			}
		$run=mysql_query($sql);
?>
<page>
	<div id="letter"><br>
	<table border="0" align="center"><tr><td align="center" style="font-size:40px;font-weight:bold;border:hidden;color:#008;"><img src="../Images/<?php echo $logo; ?>" width="100" height="100" style="float:left;margin-top:-20px;margin-left:-35px;"> &nbsp;<?php echo $cmpname; ?></td></tr></table><br>
	<hr>
	<table border="0" cellpadding="10" style="border-collapse:collapse;">
	<tr>
	<td><h2>Total Amount Paid as Salaries: N <?php echo number_format($tgrs, 2, ".", ","); ?></h2></td>
	</tr>
	</table>
	</div>
</page>
<?php
	}
?>