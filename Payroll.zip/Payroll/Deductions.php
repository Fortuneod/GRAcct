<?php
	ini_set('display_errors',0);
	
	include("connect.php");
	
	$det=mysql_query("SELECT * FROM deductions");
	$row=mysql_fetch_array($det);
	
	$tax=$row['tax'];
	$pen=$row['pension'];
	$levy=$row['levy'];
	
?>