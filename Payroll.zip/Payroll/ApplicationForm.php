<?php
ini_set('display_errors', 0);

	session_start();
	if(isset($_SESSION['formno']))
	{
		mysql_connect("localhost", "root", "");
		mysql_select_db("gradenet");

	
$formno = $_SESSION['formno'];
	
	$sql = "SELECT * FROM `applications` WHERE formno='$formno'";
	$r = mysql_query($sql);
	$count = mysql_num_rows($r);
	
		if($count>0)
		{
			while($row=mysql_fetch_array($r))
			{
				$formno= $row['formno'];
				$title=$row['title'];
				$fullname=$row['fullname'];
				$address=$row['address'];
				$phone=$row['phone'];
				$email=$row['email'];
				$sponsor=$row['sponsor'];
				$occupation=$row['occupation'];
				$education=$row['education'];
				$ictknow=$row['ictknow'];
				$medical=$row['medical'];
				$communication=$row['communication'];
				$programme1=$row['programme1'];
				$programme2=$row['programme2'];
				$agreed=$row['agreed'];
				$photo=$row['photo'];
			}
	
	

?>
<style type="text/css">
	* {margin: 0;}
	page {background:#fff;}
	#letter{width:200mm;padding-left:5mm;max-width:200mm;}
	
</style>
<page>
	<div id="letter"><br><br>
<table border="0" align="center"><tr><td align="center" style="font-size:40px;font-weight:bold;border:hidden;color:#008;"><img src="images/logo1.png" width="100" height="100" style="float:left;margin-top:-20px;margin-left:-35px;">GRADENET NIGERIA</td></tr></table><br />
   <fieldset style="color:#000;font-weight:bold;border:none;padding: 0 5px;background:url(images/logo1.png); background-repeat:no-repeat;background-position:center;background-size:80%;"><legend align="center" style="font-weight:bold;color:#008;font-size:24px;margin:auto;margin-left:-10px;">ICT TRAINING APPLICATION FORM</legend><br>
<table border="0" cellspacing="5" cellpadding="2" style="font-weight:bold;border-color:#000;width:96%;"><tr style="padding:20px 0;font-size:18px;font-weight:bold;color:#008;text-decoration:underline;"><td colspan="4" align="center">Personal Information</td></tr>
<tr style="border: 1px solid #000;">
<td align="right" colspan="4" style="border: 1px solid #000;"><img src="../Application/<?php echo $fullname;?>/Photo/<?php echo $photo; ?>" width="120" height="150" style="border: 1px solid #000;"></td>
</tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Title: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $title; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Full Name: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $fullname; ?></td>
</tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Application ID: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $formno; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Address: </td>
<td width="300" style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;word-wrap:break-word;font-size:10px;"><?php echo $address; ?></td>
</tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Phone No.(s): </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;" width="180"><?php echo $phone; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Email: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $email; ?></td>
</tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Occupation: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $occupation; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;">Sponsor </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;"><?php echo $sponsor; ?></td>
</tr>
</table><br />
<table border="0" cellspacing="5" cellpadding="2" style="font-weight:bold;vertical-align:bottom;"><tr style="padding:20px 0;font-size:18px;font-weight:bold;color:#008;text-decoration:underline;"><td colspan="4" align="center">Other Information</td></tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;padding: 2px 7px;">Highest Educational Level: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;padding: 2px 7px;"><?php echo $education; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;padding: 2px 7px;">Have You Undergone<br>Any Professional ICT <br>Certification Before?: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;padding: 2px 7px;"><?php echo $ictknow; ?></td>
</tr>
<tr style="border: 1px solid #000;">
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;padding: 2px 7px;">Do You Have Any Health<br> Challenges?: </td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;padding: 2px 7px;"><?php echo $medical; ?></td>
<td style="border-right:hidden;border-top: 1px solid #000;border-left: 1px solid #000;border-bottom: 1px solid #000;padding: 2px 7px;">Do You Want To Be<br>Included In Special <br>Communications<br>From Gradenet?:</td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;padding: 2px 7px;"><?php echo $communication; ?></td>
</tr>
</table><br>
<table border="0" cellspacing="2" cellpadding="2" align="center" style="margin-left:-35px;"><tr style="padding:20px 0;font-size:18px;font-weight:bold;color:#008;text-decoration:underline;text-align:center; "><td colspan="2"align="center" style="padding:0 0 5px;">Programme Information</td></tr>
<tr style="border: 1px solid #000;"><td align="center" colspan="2" style="font-size:20px;font-weight:bold;padding:0;border: 1px solid #000;vertical-align:middle;" width="650">Programmes Applied For</td>
</tr>
<tr style="border: 1px solid #000;"><td style="font-size:16px;font-weight:bold;color:#008;border: 1px solid #000;padding: 2px 0 0 7px ;">Programme 1</td>
	<td style="font-size:16px;font-weight:bold;color:#008;border: 1px solid #000;padding: 2px 0 0 7px;">Programme 2</td></tr>
<tr style="border: 1px solid #000;">
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;border: 1px solid #000;padding: 2px 7px;"><?php echo $programme1; ?></td>
<td style="border-top: 1px solid #000;border-bottom: 1px solid #000;border-right: 1px solid #000;border: 1px solid #000;padding: 2px 7px;"><?php echo $programme2; ?></td>
</tr>
</table><br /><br />
<table border="0" cellspacing="2" align="center" style="border:hidden;margin-top:15px;margin-left:-35px;">
<tr>
<td align="center" style="padding-top:75px;border:hidden;"> Do You Agree to all Terms and Conditions of Gradnet ICT?:</td>
<td align="left" style="border:hidden;text-decoration:underline;padding-top:75px;"><?php echo $agreed; ?></td>
<td style="border:hidden;"></td><td style="border:hidden;"></td><td style="border:hidden;"></td><td style="border:hidden;"></td><td style="border:hidden;"></td>
<td style="padding-top:75px;">Signature and Date: ________________ </td>
</tr>
</table>
</fieldset><br> 
</div>
</page>

<?php 
	}
}

?>